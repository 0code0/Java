package neural;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Random;
import java.util.Vector;

/**
 *
 * @author singhj1
 */
public class Neural {

    //private static double[] Input = new double[]{1.0, 1.0};
    public Neural(int FirstLayer, int SecondLayer, int ThirdLayer) {

        double[][] Input = new double[1][FirstLayer];

        double[] WEIGHTS = new double[(FirstLayer * SecondLayer) + (SecondLayer * ThirdLayer)];
        double[] BIASES = new double[(SecondLayer + ThirdLayer)];
        double[] ActivationResult = new double[SecondLayer];
        double HiddenNeuronValue = 0;
        double OUTPUT = new Double(ThirdLayer);

        Random random = new Random();

        for (int i = 0; i < Input.length; i++) {

            for (int j = 0; j < FirstLayer; j++) {

                Input[i][j] = BigDecimal.valueOf(random.nextFloat()).setScale(1, RoundingMode.HALF_UP).doubleValue();

            }
        }

        for (int i = 0; i < WEIGHTS.length; i++) {

            WEIGHTS[i] = BigDecimal.valueOf(random.nextFloat()).setScale(1, RoundingMode.HALF_UP).doubleValue();

        }

        for (int i = 0; i < BIASES.length; i++) {

            BIASES[i] = BigDecimal.valueOf(random.nextFloat()).setScale(1, RoundingMode.HALF_UP).doubleValue();

        }

        for (int i = 0; i < SecondLayer; i++) {

            for (int j = 0; j < FirstLayer; j++) {

                HiddenNeuronValue += (Input[0][j] * WEIGHTS[j]);

            }

            HiddenNeuronValue += BIASES[i];
            // ActivationResult[i] = Sigmoid(((Input[0] * WEIGHTS[i]) + (Input[1] * WEIGHTS[i + SecondLayer])) + BIASES[i]);
        }
        //System.out.println(HiddenNeuronValue);

        for (int i = SecondLayer; i < BIASES.length; i++) {

            for (int j = 0; j < SecondLayer; j++) {

                //   OUTPUT[i] += (ActivationResult[j] * WEIGHTS[j + (FirstLayer * SecondLayer)]);
            }

        }

    }

    public static double Sigmoid(double z) {

        return BigDecimal.valueOf(1.0 / (1.0 + Math.exp(-z))).setScale(2, RoundingMode.HALF_UP).doubleValue();

    }

    public static void main(String[] args) {

        Neural neural = new Neural(784, 30, 10);

    }

}
